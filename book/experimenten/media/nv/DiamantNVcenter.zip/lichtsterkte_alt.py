# Necessary imports
from serial import Serial
import matplotlib.pyplot as plt
import numpy as np
import argparse

class DiamondNVCenter:

    def __init__(self, integration_time, TSL2591_port):
        self.TSL2591 = Serial(TSL2591_port, 9600)
        self.integration_time = integration_time
        self.total_number_of_data_points = np.zeros(1)  # set later on
        self.time_axis = np.zeros(1)  # set later on
        self.data_points = np.zeros(1)  # set later on
        self.store_figure = False
        self.sensor_warmup()

    def measurement(self, measurement_time, ymin, ymax):
        number_of_data_points = int(measurement_time/self.integration_time)
        time_axis = np.linspace(0, measurement_time, number_of_data_points)
        measurements = np.zeros(number_of_data_points)
        count = 0

        plt.figure()

        while True:
            if self.TSL2591.in_waiting > 0:
                if self.TSL2591.in_waiting > 5:
                    useless_data = self.TSL2591.readline().decode().strip()
                else:
                    line = self.TSL2591.readline().decode().strip()
                    if line:
                        if count < number_of_data_points:
                            measurements[count] = float(line)

                        self.plot_time_measurement(measurements, time_axis, ymin, ymax)
                        count += 1
                    if count > number_of_data_points:
                        break

    def sensor_warmup(self):
        print("Starting warm up")
        dummy_data = []
        length_dataset = 2
        while True:
            if self.TSL2591.in_waiting > 0:
                line = self.TSL2591.readline().decode().strip()
                if line:
                    dummy_data.append(float(line))
                if len(dummy_data) >= length_dataset:
                    break
        print("Warm up done!")

    def plot_time_measurement(self, measurements, time_axis, ymin, ymax):
        plt.clf()  
        plt.scatter(time_axis, measurements)
        plt.ylabel("Bit value")
        plt.xlabel("Time (s)")
        plt.title("Timed Measurement")
        plt.grid()
        
        if np.max(measurements)==0:
            plt.ylim(0, 10)
        #elif np.max(measurements)<=np.max(measurements)*ymin:
            #ymin *= 0.9           
        else:
            plt.ylim(np.max(measurements)*ymin, np.max(measurements)*ymax)
        
        plt.pause(0.05)

    def close_connection(self):
        print("Closing the connection")
        self.TSL2591.close()
        print("Connection closed")
        
def main():
    # Parse command-line arguments including ymin and ymax
    parser = argparse.ArgumentParser(description='Process input arguments.')
    parser.add_argument('--time', type=int, help='Time value')
    parser.add_argument('--ymin', type=float, help='Min value for y-axis')
    parser.add_argument('--ymax', type=float, help='Max value for y-axis')
    parser.add_argument('--COM', type=str, help='COM Port')
    args = parser.parse_args()
    time = args.time
    ymin = args.ymin
    ymax = args.ymax
    com_port = args.COM

#    print("Received time:", time)
#    print("Received ymin:", ymin)
#    print("Received ymax:", ymax)
#    print("Received COM port:", com_port)
    
    diode_integration_time = 0.6
    delay_between_measurements = 0.5
    integration_time = diode_integration_time + delay_between_measurements
    NV_center = DiamondNVCenter(integration_time, com_port)
    NV_center.measurement(time, ymin, ymax)
    NV_center.close_connection()

if __name__ == "__main__":
    main()
