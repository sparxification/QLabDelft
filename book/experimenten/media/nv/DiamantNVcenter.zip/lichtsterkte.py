from serial import Serial  # use pip install pyserial
import time  # pip install time
import matplotlib.pyplot as plt  # pip install matplotlib
import numpy as np  # pip install numpy
from IPython.display import display, clear_output


class DiamondNVCenter:

    def __init__(self, integration_time, TSL2591_port="COM6"):
        self.TSL2591 = Serial(TSL2591_port, 9600)
        self.integration_time = integration_time
        self.total_number_of_data_points = np.zeros(1)  # set later on
        self.time_axis = np.zeros(1)  # set later on
        self.data_points = np.zeros(1)  # set later on

        # do you want to store the data arrays?
        self.store_figure = False

        self.sensor_warmup()
    def magnet_noRF_normalized_readout_and_show(self, time_per_mag_pos, magnet_placements, distance_magnet_to_top_lid):
        '''
        Makes a plot of the normalized measurements and asks to change the position of the magnet
        :param time_per_mag_pos: the number of seconds you want to run for 1 magnet position
        :param magnet_placements: an array of the positions of the magnet with regard to the diamonds in centimeters
        :return: plot of the normalized measurement
        '''
        self.total_number_of_data_points = round((time_per_mag_pos*len(magnet_placements))/self.integration_time)
        self.time_axis = np.linspace(0, time_per_mag_pos*len(magnet_placements), self.total_number_of_data_points)
        self.data_points = np.zeros(self.total_number_of_data_points)
        average = np.zeros_like(magnet_placements)
        average_sum = 0
        average_counter = 0

        iter = 0

        for i in range(len(magnet_placements)):
            input(f"Make sure to put the magnet in the {magnet_placements[i]} cm position\n"
                  f"Hit enter if you are ready")
            while True:
                if self.TSL2591.in_waiting > 0:
                    '''this is done to make sure it uses the correct data instead of the waiting line'''
                    if self.TSL2591.in_waiting > 5:
                        # print(f"de waiting line LANG:{self.TSL2591.in_waiting}")
                        useless_data = self.TSL2591.readline().decode().strip()

                    else:
                        # print(f"de waiting line:{self.TSL2591.in_waiting}")
                        line = self.TSL2591.readline().decode().strip()
                        if line:
                            self.data_points[iter] = float(line)
                            average_sum += float(line)
                            average_counter += 1

                            iter += 1

                        if iter >= len(self.data_points) or average_counter >= time_per_mag_pos:
                            break

            average[i] = average_sum / average_counter

            average_sum = 0
            average_counter = 0
            time.sleep(0.1)

        # time to plot

        x_values1 = self.time_axis
        y_values1 = self.data_points/np.max(self.data_points)

        magnet_placements = [(x ** 2 + distance_magnet_to_top_lid ** 2) ** 0.5 for x in magnet_placements]

        x_values2 = magnet_placements
        y_values2 = average/np.max(average)

        fig = plt.figure()
        # plt.grid()
        ax = fig.add_subplot(111, label="1")
        ax2 = fig.add_subplot(111, label="2", frame_on=False)
        ax2.set_ylim(0.95, 1.01)

        ax.set_ylim(0.95, 1.01)
        ax.scatter(x_values2, y_values2, color="C0")
        ax.set_xlabel('Magnet positions (cm)', color="C0")
        ax.set_ylabel('Average Luminosity ratio', color="C0")
        ax.tick_params(axis='x', colors="C0")
        ax.tick_params(axis='y', colors="C0")

        ax2.xaxis.tick_top()
        ax2.yaxis.tick_right()
        ax2.xaxis.set_label_position('top')
        ax2.yaxis.set_label_position('right')
        ax2.plot(x_values1, y_values1, color="C1", ls='--')
        ax2.set_xlabel('Time (s)', color="C1")
        ax2.set_ylabel('Luminosity ratio', color="C1")
        ax2.tick_params(axis='x', colors="C1")
        ax2.tick_params(axis='y', colors="C1")
        plt.tight_layout()

        plt.grid()
        plt.title(f'Luminosity vs. Time\nNormalized')
        # plt.legend()
        plt.tight_layout()

        if self.store_figure:
            plt.savefig(f'../figures/magnet_test.png',
                        transparent=False,
                        facecolor='white'
                        )

        plt.show()

    def continuous_measurement(self):
        number_of_data_points = 50
        measurements = np.zeros(number_of_data_points)
        count = 0
        # plt.ion()

        plt.figure()

        while True:
            if self.TSL2591.in_waiting > 0:
                '''this is done to make sure it uses the correct data instead of the waiting line'''
                if self.TSL2591.in_waiting > 5:
                    # print(f"de waiting line LANG:{self.TSL2591.in_waiting}")
                    useless_data = self.TSL2591.readline().decode().strip()

                else:
                    # print(f"de waiting line:{self.TSL2591.in_waiting}")
                    line = self.TSL2591.readline().decode().strip()
                    if line:
                        if count < number_of_data_points:
                            measurements[count] = float(line)
                        else:
                            measurements_new = np.zeros_like(measurements)
                            # print(measurements[:-1])
                            # print(measurements[1:])
                            measurements_new[:-1] = measurements[1:]
                            measurements_new[-1] = float(line)
                            measurements = measurements_new

                        self.plot_continuous(measurements)
                        count += 1
                    if count > number_of_data_points*3:
                        break
        # plt.show()

    def measurement(self, measurement_time):
        number_of_data_points = int(measurement_time/self.integration_time)
        time_axis = np.linspace(0, measurement_time, number_of_data_points)
        measurements = np.zeros(number_of_data_points)
        count = 0

        plt.figure()

        while True:
            if self.TSL2591.in_waiting > 0:
                '''this is done to make sure it uses the correct data instead of the waiting line'''
                if self.TSL2591.in_waiting > 5:
                    # print(f"de waiting line LANG:{self.TSL2591.in_waiting}")
                    useless_data = self.TSL2591.readline().decode().strip()

                else:
                    # print(f"de waiting line:{self.TSL2591.in_waiting}")
                    line = self.TSL2591.readline().decode().strip()
                    if line:
                        if count < number_of_data_points:
                            measurements[count] = float(line)

                        self.plot_time_measurement(measurements, time_axis)
                        count += 1
                    if count > number_of_data_points:
                        break
        # plt.show()



    '''------------------- ALL HELPER FUNCTION BELOW THIS PART -------------------'''

    def sensor_warmup(self):
        '''
        This function just takes 5 values from the sensor to warm it up a bit
        '''
        print("Starting warm up")
        dummy_data = []
        length_dataset = 2  # change this value for warmup time
        while True:
            if self.TSL2591.in_waiting > 0:
                line = self.TSL2591.readline().decode().strip()
                if line:
                    dummy_data.append(float(line))

                if len(dummy_data) >= length_dataset:
                    break
        print("Warm up done!")

    def plot_continuous(self, measurements):

        plt.clf()  # Clear the previous plot
        plt.plot(measurements)
        plt.ylabel("Bit value")
        plt.title("Continuous Measurement")
        plt.grid()
        plt.ylim(np.max(measurements)*0.5, np.max(measurements)*1.5)
        plt.pause(0.05)  # Add a small pause to update the plot

        # plt.plot(measurements)
        # plt.ylabel("Bit value")
        # plt.title("Continuous Measurement")
        # plt.grid()
        # plt.ylim(np.max(measurements)-100, np.max(measurements)+5)
        # plt.show()

    def plot_time_measurement(self, measurements, time_axis):

        plt.clf()  # Clear the previous plot
        plt.scatter(time_axis, measurements)
        plt.ylabel("Bit value")
        plt.xlabel("Time (s)")
        plt.title("Timed Measurement")
        plt.grid()
        plt.ylim(np.max(measurements)*0.96, np.max(measurements)*1.01)
        plt.pause(0.05)  # Add a small pause to update the plot

    def close_connection(self):
        print("Closing the connection")
        self.TSL2591.close()
        print("Connection closed")



if __name__ == "__main__":

    # initialize the NV center
    diode_integration_time = 0.6  # seconds
    delay_between_measurements = 0.5  # seconds
    integration_time = diode_integration_time + delay_between_measurements
    NV_center = DiamondNVCenter(integration_time)

    # I want to store the figure
    NV_center.store_figure = True

    '''No RF just magnet position changing'''
    distance_magnet_to_top_lid = 1  # cm

    # magnet_placement = [0, 1, 2, 3, 4, 5, 6, 7]
    magnet_placement = [0, 2, 4, 6, 8]
    # magnet_placement = magnet_placement[::-1]

    runtime_for_magnets = 10  # seconds

    #NV_center.magnet_noRF_normalized_readout_and_show(runtime_for_magnets, magnet_placement, distance_magnet_to_top_lid)

    #NV_center.continuous_measurement()
    # closing the connection
    
    NV_center.measurement(60)
    NV_center.close_connection()
